# freshness_apple > 2024-09-29 9:53am
https://universe.roboflow.com/mridul-wlxfb/freshness_apple

Provided by a Roboflow user
License: CC BY 4.0

